let total = 0;

function addToCart(itemName, price) {
  total += price;
  const totalElement = document.getElementById("cart-total");
  totalElement.textContent = `Total: ₹${total}`;
}
document.getElementById("pay-button").addEventListener("click", () => {
  if (total === 0) {
    alert("Cart is empty!");
    return;
  }

  document.getElementById("payment-message").textContent = "✅ Payment Successful!";
  setTimeout(() => {
    document.getElementById("payment-message").textContent = "Thank you for your order!";
  }, 2000); 

  total = 0;
  document.getElementById("cart-total").textContent = "Total: ₹0";
});
